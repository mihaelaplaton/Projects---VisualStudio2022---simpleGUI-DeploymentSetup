﻿CREATE TABLE [dbo].[myTable]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [name] NCHAR(20) NULL, 
    [email] NCHAR(20) NULL, 
    [telephone] NUMERIC NULL
)





