﻿

CREATE TABLE [dbo].[FormExample]
(
    [name] NCHAR(20) NULL, 
    [email] NCHAR(20) NULL, 
    [telephone] NCHAR(20) NULL
)
