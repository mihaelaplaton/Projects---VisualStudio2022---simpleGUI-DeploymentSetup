#pragma once

namespace firstGUI {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::Data::SqlClient;

	/// <summary>
	/// Summary for MyForm
	/// </summary>
	public ref class MyForm : public System::Windows::Forms::Form
	{
	public:
		MyForm(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::TextBox^ txtname;
	private: System::Windows::Forms::TextBox^ txttelephone;


	private: System::Windows::Forms::TextBox^ txtemail;
	private: System::Windows::Forms::Button^ btnSubmit;
	private: System::Windows::Forms::Button^ btnCancel;


	private: System::Windows::Forms::Button^ btnSearch;




	protected:

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container^ components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->txtname = (gcnew System::Windows::Forms::TextBox());
			this->txttelephone = (gcnew System::Windows::Forms::TextBox());
			this->txtemail = (gcnew System::Windows::Forms::TextBox());
			this->btnSubmit = (gcnew System::Windows::Forms::Button());
			this->btnCancel = (gcnew System::Windows::Forms::Button());
			this->btnSearch = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(30, 32);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(59, 20);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Name: ";
			this->label1->Click += gcnew System::EventHandler(this, &MyForm::label1_Click);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(30, 77);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(73, 20);
			this->label2->TabIndex = 1;
			this->label2->Text = L"Email ID:";
			this->label2->Click += gcnew System::EventHandler(this, &MyForm::label2_Click);
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(30, 133);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(92, 20);
			this->label3->TabIndex = 2;
			this->label3->Text = L"Telephone :";
			this->label3->Click += gcnew System::EventHandler(this, &MyForm::label3_Click);
			// 
			// txtname
			// 
			this->txtname->Location = System::Drawing::Point(137, 32);
			this->txtname->Name = L"txtname";
			this->txtname->Size = System::Drawing::Size(237, 26);
			this->txtname->TabIndex = 3;
			this->txtname->TextChanged += gcnew System::EventHandler(this, &MyForm::textBox1_TextChanged);
			// 
			// txttelephone
			// 
			this->txttelephone->Location = System::Drawing::Point(137, 130);
			this->txttelephone->Name = L"txttelephone";
			this->txttelephone->Size = System::Drawing::Size(237, 26);
			this->txttelephone->TabIndex = 4;
			this->txttelephone->TextChanged += gcnew System::EventHandler(this, &MyForm::textBox2_TextChanged);
			// 
			// txtemail
			// 
			this->txtemail->Location = System::Drawing::Point(137, 74);
			this->txtemail->Name = L"txtemail";
			this->txtemail->Size = System::Drawing::Size(237, 26);
			this->txtemail->TabIndex = 5;
			this->txtemail->TextChanged += gcnew System::EventHandler(this, &MyForm::textBox3_TextChanged);
			// 
			// btnSubmit
			// 
			this->btnSubmit->Location = System::Drawing::Point(118, 197);
			this->btnSubmit->Name = L"btnSubmit";
			this->btnSubmit->Size = System::Drawing::Size(112, 59);
			this->btnSubmit->TabIndex = 6;
			this->btnSubmit->Text = L"Submit";
			this->btnSubmit->UseVisualStyleBackColor = true;
			this->btnSubmit->Click += gcnew System::EventHandler(this, &MyForm::Submit_Click);
			// 
			// btnCancel
			// 
			this->btnCancel->Location = System::Drawing::Point(267, 197);
			this->btnCancel->Name = L"btnCancel";
			this->btnCancel->Size = System::Drawing::Size(107, 59);
			this->btnCancel->TabIndex = 7;
			this->btnCancel->Text = L"Cancel";
			this->btnCancel->UseVisualStyleBackColor = true;
			this->btnCancel->Click += gcnew System::EventHandler(this, &MyForm::Cancel_Click);
			// 
			// btnSearch
			// 
			this->btnSearch->Location = System::Drawing::Point(425, 43);
			this->btnSearch->Name = L"btnSearch";
			this->btnSearch->Size = System::Drawing::Size(123, 113);
			this->btnSearch->TabIndex = 8;
			this->btnSearch->Text = L"Search";
			this->btnSearch->UseVisualStyleBackColor = true;
			this->btnSearch->Click += gcnew System::EventHandler(this, &MyForm::btnSearch_Click);
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(9, 20);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(560, 288);
			this->Controls->Add(this->btnSearch);
			this->Controls->Add(this->btnCancel);
			this->Controls->Add(this->btnSubmit);
			this->Controls->Add(this->txtemail);
			this->Controls->Add(this->txttelephone);
			this->Controls->Add(this->txtname);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Name = L"MyForm";
			this->Text = L"MyForm";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void label3_Click(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void label2_Click(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void label1_Click(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void textBox3_TextChanged(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void textBox1_TextChanged(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void textBox2_TextChanged(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void Cancel_Click(System::Object^ sender, System::EventArgs^ e) {
		this->txtemail->Text = "";
		this->txtname->Text = "";
		this->txttelephone->Text = "";
	}


	private: System::Void Submit_Click(System::Object^ sender, System::EventArgs^ e) {

		if (this->txtemail->Text->Trim() == "")
		{
			MessageBox::Show("Please Enter email ", "Validation", MessageBoxButtons::OK, MessageBoxIcon::Error);
		}
		else if (this->txtname->Text->Trim() == "")
		{
			MessageBox::Show("Please Enter name ", "Validation", MessageBoxButtons::OK, MessageBoxIcon::Error);
		}
		else if (this->txttelephone->Text->Trim() == "")
		{
			MessageBox::Show("Please Enter telephone ", "Validation", MessageBoxButtons::OK, MessageBoxIcon::Error);
		}

		else
		{
			try
			{
				String^ connectionString = "Data Source=DESKTOP-1BLQPVI;Initial Catalog=MyDatabase;Integrated Security=True";
				SqlConnection con(connectionString);
				con.Open();
				String^ sqlQuery = "Insert into FormExample values ('"+this->txtname->Text+"','"+this->txtemail->Text+"','"+this->txttelephone->Text+"')";
				SqlCommand cmd(sqlQuery, % con);
				cmd.ExecuteNonQuery();
				con.Close();
				MessageBox::Show("data submitted ", "Validation", MessageBoxButtons::OK, MessageBoxIcon::Information);
				this->txtemail->Text = "";
				this->txtname->Text = "";
				this->txttelephone->Text = "";
			}
			catch (Exception^ ex) {
				throw ex;
			}
		}
	}
private: System::Void btnSearch_Click(System::Object^ sender, System::EventArgs^ e) {
	try
	{
		String^ connectionString = "Data Source=DESKTOP-1BLQPVI;Initial Catalog=MyDatabase;Integrated Security=True";
		SqlConnection con(connectionString);
		con.Open();
		String^ sqlQuery = "select * from FormExample where name like ('%"+ this->txtname->Text +"%')";
		//String^ sqlQuery = "select * from dbo.FormExample where name like ''%"+1+"%'";
		SqlCommand cmd(sqlQuery, % con);
		SqlDataReader^ dr = cmd.ExecuteReader();

		if (dr->Read())
		{
			String^ result = "Name" + dr["name"]->ToString() + "Email" + dr["email"]->ToString() + "Telephone" + dr["telephone"]->ToString();
			
			dr->Close();
			MessageBox::Show(result, "Success", MessageBoxButtons::OK, MessageBoxIcon::Information);
		}
		else
		{
			dr->Close();
			MessageBox::Show("no data found ", "Success", MessageBoxButtons::OK, MessageBoxIcon::Information);
			
		}
		con.Close();
	}
	catch (Exception^ ex) {
		throw ex;
	}

}
};
}
