#include "MyForm.h"

using namespace System;
using namespace System::Windows::Forms;
//void main(array<String^>^ args)
int  main(array<String^>^ argv)
{
	Application::EnableVisualStyles();
	Application::SetCompatibleTextRenderingDefault(false);
	firstGUI::MyForm form;
	Application::Run(% form);
}

